function fn() {   
  var env = 'test'; // get java system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'test'; // a custom 'intelligent' default
  }
  var config = { // base config JSON
 	env : 'test',
    appId: 'my.app.id',
    appSecret: 'my.secret',
    POSTURL: 'http://services.odata.org/V4/TripPinService/People',
    GETURL: 'http://services.odata.org/V4/TripPinService/'
  };
  if (env == 'stage') {
    // over-ride only those that need to be
    config.someUrlBase = 'https://stage-host/v1/auth';
  } else if (env == 'e2e') {
    config.someUrlBase = 'https://e2e-host/v1/auth';
  }
  // don't waste time waiting for a connection or if servers don't respond within 5 seconds
  karate.configure('connectTimeout', 5000);
  karate.configure('readTimeout', 5000);
  return config;
}